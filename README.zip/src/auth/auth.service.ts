import { Injectable } from '@nestjs/common';

@Injectable({})
export class AuthService {
  signin() {
    return 'signed in';
  }

  signup() {
    return 'signed up';
  }
}